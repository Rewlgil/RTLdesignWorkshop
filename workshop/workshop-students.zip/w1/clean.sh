#!/usr/bin/env bash

# clean
rm sim sim.vcd
