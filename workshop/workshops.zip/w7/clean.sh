#!/usr/bin/env bash

# clean
rm -f sim sim.vcd
